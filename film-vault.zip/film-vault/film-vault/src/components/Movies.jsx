/* eslint-disable no-unused-vars */
import React from "react";
import MovieCard from "./MovieCard";
import { useEffect } from "react";
import axios from "axios";
import { useState } from "react";
import Pagination from "./Pagination";

// eslint-disable-next-line react/prop-types
function Movies({handleAddtoWatchList, handleRemoveFromWatchlist, watchlist}) {

    const [movies , setMovies] = useState([])
    const [pageNo, setPageNo] = useState(1)

    const handlePrev = () => {
        if(pageNo == 1){
            setPageNo(pageNo);
        }
        else{
            setPageNo(pageNo - 1);
        }
        
    }

    const handleNext = () => {
      setPageNo(pageNo+1);
    };



    useEffect(() => {
      axios
        .get(`https://api.themoviedb.org/3/movie/popular?api_key=43367f269b5ea8ec9cb732558d1d9f08&language=en-US&page=${pageNo}`
        )
        .then(function (res) {
          setMovies(res.data.results);
        });
    }, [pageNo]);
return (
<div className="p-5">
    <div className="text-2xl m-5 font-bold text-center">
        Trending Movies
    </div>

    <div className='flex flex-row flex-wrap justify-around m-10 gap-8'>
        {movies.map((movieObj)=>{
            return <MovieCard key={movieObj.id} movieObj={movieObj} poster_path={movieObj.poster_path} name={movieObj.original_title} handleAddtoWatchList={handleAddtoWatchList} handleRemoveFromWatchlist={handleRemoveFromWatchlist} watchlist={watchlist} />
        })}  
    </div>

    <Pagination pageNo={pageNo} handleNext={handleNext} handlePrev={handlePrev} />

</div>
);
}

export default Movies;

//https://api.themoviedb.org/3/movie/popular?api_key=43367f269b5ea8ec9cb732558d1d9f08&language=en-US&page=1